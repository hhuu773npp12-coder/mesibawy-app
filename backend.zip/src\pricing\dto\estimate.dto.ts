export class EstimateDto {
  category!: 'taxi' | 'tuk_tuk' | 'kia_passenger' | 'kia_haml' | 'stuta' | 'bike';
  distanceKm!: number;
  durationMin?: number;
}
